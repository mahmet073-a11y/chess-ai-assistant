# Chess Training Assistant
Android yüzen pencere satranç antrenman prototipi. Basitleştirilmiş hamle kuralları ve basit öneriler; şah güvenliği, rok, geçerken alma ve güçlü motor analizi henüz yoktur.

## APK
GitHub Actions > Build Android APK > Run workflow. Başarılı derleme sonrası Artifacts bölümünden debug APK indirilir.

Not: GitHub web arayüzü ZIP içindeki klasörleri otomatik açmaz. ZIP'i telefonda çıkartıp dosyaları klasör yapısını koruyarak yüklemek veya bir Git istemcisi kullanmak gerekir.
