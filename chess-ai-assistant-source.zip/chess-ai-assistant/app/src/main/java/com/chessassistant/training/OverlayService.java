package com.chessassistant.training;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;
public class OverlayService extends Service {
 WindowManager wm; FrameLayout root;
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);
 root=new FrameLayout(this);
 WebView web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);
 web.loadUrl("file:///android_asset/chess.html");root.addView(web);
 TextView close=new TextView(this);close.setText("  ×  ");close.setTextSize(25);close.setTextColor(0xffff3333);close.setBackgroundColor(0xeeffffff);
 FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT);root.addView(close,cp);close.setOnClickListener(v->stopSelf());
 WindowManager.LayoutParams p=new WindowManager.LayoutParams(330,470,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;p.x=20;p.y=160;
 wm.addView(root,p);
 }
 @Override public int onStartCommand(Intent i,int flags,int id){return START_NOT_STICKY;}
 @Override public void onDestroy(){if(root!=null)wm.removeView(root);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
