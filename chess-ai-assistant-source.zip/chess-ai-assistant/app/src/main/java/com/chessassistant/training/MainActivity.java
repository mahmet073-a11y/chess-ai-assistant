package com.chessassistant.training;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);
 LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(35,50,35,20);
 TextView text=new TextView(this);text.setText("Chess Training Assistant\nAntrenman tahtası ve yüzen pencere. Öneriler basit bir prototip algoritmasıdır; güçlü satranç motoru değildir.");text.setTextSize(19);layout.addView(text);
 Button start=new Button(this);start.setText("Yüzen pencereyi aç");layout.addView(start);
 Button stop=new Button(this);stop.setText("Pencereyi kapat");layout.addView(stop);
 setContentView(layout);
 start.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}else startService(new Intent(this,OverlayService.class));});
 stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class)));
 }
}
